===============================================================================
 FruitMeasureStick — Arxius STL i instruccions d'impressió 3D
 FruitMeasureStick — Archivos STL e instrucciones de impresión 3D
 FruitMeasureStick — STL files and 3D printing instructions
===============================================================================

 Versió / Versión / Version: V02 — Setembre / Septiembre / September 2026

 Autor / Autor / Author:
   Jordi Gené Mola (Jordi.gene@irta.cat)

FruitMeasureApp ha estat desenvolupada per la Universitat de Lleida (UdL) i l'Institut de Recerca i Tecnologia Agroalimentàries (IRTA) en el marc del projecte demostratiu FruitMeasureApp: Validació i prototipatge d'una aplicació mòbil basada en IA per mesurar fruits en camp (Activitat cofinançada per la UE a través de la intervenció 7201 del Pla Estratègic de la PAC 2023-2027).

===============================================================================
 LLICÈNCIA / LICENCIA / LICENSE
===============================================================================

 © 2026 Jordi Gené Mola — Institut de Recerca i Tecnologia Agroalimentàries
 (IRTA).

 Aquesta obra està llicenciada sota una llicència
 Creative Commons Reconeixement-NoComercial 4.0 Internacional (CC BY-NC 4.0).

 Esta obra está licenciada bajo una licencia
 Creative Commons Reconocimiento-NoComercial 4.0 Internacional (CC BY-NC 4.0).

 This work is licensed under a
 Creative Commons Attribution-NonCommercial 4.0 International License
 (CC BY-NC 4.0).

 https://creativecommons.org/licenses/by-nc/4.0/

 Podeu copiar, distribuir i adaptar aquest material sempre que en reconegueu
 l'autoria i no en feu un ús comercial.
 Puede copiar, distribuir y adaptar este material siempre que reconozca la
 autoría y no haga un uso comercial del mismo.
 You may copy, distribute and adapt this material provided that you give
 appropriate credit and do not use it for commercial purposes.

===============================================================================
